<?php

$con=new mysqli("localhost","root","","hospital");
	            if(!$con)
	            {
	            	die(mysqli_error($con));
	            }

?>